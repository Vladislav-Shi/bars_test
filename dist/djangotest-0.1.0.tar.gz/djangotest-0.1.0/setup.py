# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['m3_project',
 'm3_project.app',
 'm3_project.app.migrations',
 'm3_project.m3_project']

package_data = \
{'': ['*']}

install_requires = \
['django==2.2.2', 'm3-django-compat==1.9.2', 'm3-objectpack==2.2.47']

setup_kwargs = {
    'name': 'djangotest',
    'version': '0.1.0',
    'description': '',
    'long_description': '## Тестовое по питону\n\n### С использованием Poetry',
    'author': 'Vladislav-Shi',
    'author_email': 'vlad.shirobockow@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '==3.8.1',
}


setup(**setup_kwargs)
